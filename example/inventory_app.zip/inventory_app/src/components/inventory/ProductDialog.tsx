import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Product, Category, UNITS } from '@/data/inventoryData';

interface ProductDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  product: Product | null;
  categories: Category[];
  onSave: (product: Product) => void;
}

export function ProductDialog({ open, onOpenChange, product, categories, onSave }: ProductDialogProps) {
  const [form, setForm] = useState<Partial<Product>>({});

  useEffect(() => {
    if (product) {
      setForm({ ...product });
    } else {
      setForm({
        name: '', sku: '', category: categories[0]?.id || '', description: '',
        unit: 'cái', price: 0, costPrice: 0, quantity: 0, minStock: 5,
        location: '', supplier: '',
      });
    }
  }, [product, open, categories]);

  const handleSubmit = () => {
    if (!form.name || !form.sku) return;
    onSave(form as Product);
  };

  const update = (field: string, value: string | number) => setForm(f => ({ ...f, [field]: value }));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{product ? 'Sửa sản phẩm' : 'Thêm sản phẩm mới'}</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-4 py-4">
          <div className="col-span-2">
            <Label>Tên sản phẩm *</Label>
            <Input value={form.name || ''} onChange={e => update('name', e.target.value)} placeholder="VD: Laptop Dell Inspiron" />
          </div>
          <div>
            <Label>Mã SKU *</Label>
            <Input value={form.sku || ''} onChange={e => update('sku', e.target.value)} placeholder="VD: DELL-INS15" />
          </div>
          <div>
            <Label>Danh mục</Label>
            <Select value={form.category || ''} onValueChange={v => update('category', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {categories.map(c => (
                  <SelectItem key={c.id} value={c.id}>{c.icon} {c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <Label>Mô tả</Label>
            <Input value={form.description || ''} onChange={e => update('description', e.target.value)} />
          </div>
          <div>
            <Label>Đơn vị tính</Label>
            <Select value={form.unit || 'cái'} onValueChange={v => update('unit', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {UNITS.map(u => <SelectItem key={u} value={u}>{u}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Số lượng ban đầu</Label>
            <Input type="number" min={0} value={form.quantity ?? 0} onChange={e => update('quantity', Number(e.target.value))} />
          </div>
          <div>
            <Label>Giá bán (VNĐ)</Label>
            <Input type="number" min={0} value={form.price ?? 0} onChange={e => update('price', Number(e.target.value))} />
          </div>
          <div>
            <Label>Giá vốn (VNĐ)</Label>
            <Input type="number" min={0} value={form.costPrice ?? 0} onChange={e => update('costPrice', Number(e.target.value))} />
          </div>
          <div>
            <Label>Tồn kho tối thiểu</Label>
            <Input type="number" min={0} value={form.minStock ?? 5} onChange={e => update('minStock', Number(e.target.value))} />
          </div>
          <div>
            <Label>Vị trí kho</Label>
            <Input value={form.location || ''} onChange={e => update('location', e.target.value)} placeholder="VD: A1-01" />
          </div>
          <div className="col-span-2">
            <Label>Nhà cung cấp</Label>
            <Input value={form.supplier || ''} onChange={e => update('supplier', e.target.value)} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Hủy</Button>
          <Button onClick={handleSubmit} disabled={!form.name || !form.sku}>
            {product ? 'Cập nhật' : 'Thêm mới'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
