import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Product, StockMovement, MOVEMENT_REASONS } from '@/data/inventoryData';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface StockDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  product: Product;
  type: 'in' | 'out';
  onSave: (movement: StockMovement) => void;
}

export function StockDialog({ open, onOpenChange, product, type, onSave }: StockDialogProps) {
  const [quantity, setQuantity] = useState(1);
  const [reason, setReason] = useState(MOVEMENT_REASONS[type][0]);
  const [note, setNote] = useState('');

  const handleSubmit = () => {
    if (quantity <= 0) return;
    if (type === 'out' && quantity > product.quantity) return;
    onSave({
      id: '',
      productId: product.id,
      type,
      quantity,
      reason,
      note,
      date: '',
      createdBy: 'Admin',
    });
    setQuantity(1);
    setNote('');
  };

  const isIn = type === 'in';
  const Icon = isIn ? TrendingUp : TrendingDown;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className={`flex items-center gap-2 ${isIn ? 'text-green-600' : 'text-orange-600'}`}>
            <Icon className="h-5 w-5" />
            {isIn ? 'Nhập kho' : 'Xuất kho'} — {product.name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="text-sm text-gray-500">
            Tồn kho hiện tại: <span className="font-bold text-gray-900 dark:text-white">{product.quantity} {product.unit}</span>
          </div>

          <div>
            <Label>Số lượng *</Label>
            <Input
              type="number"
              min={1}
              max={type === 'out' ? product.quantity : undefined}
              value={quantity}
              onChange={e => setQuantity(Number(e.target.value))}
            />
            {type === 'out' && quantity > product.quantity && (
              <p className="text-xs text-red-500 mt-1">Số lượng xuất không được vượt quá tồn kho ({product.quantity})</p>
            )}
          </div>

          <div>
            <Label>Lý do</Label>
            <Select value={reason} onValueChange={setReason}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {MOVEMENT_REASONS[type].map(r => (
                  <SelectItem key={r} value={r}>{r}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Ghi chú</Label>
            <Input value={note} onChange={e => setNote(e.target.value)} placeholder="VD: Đơn hàng #PO-123" />
          </div>

          <div className={`text-sm p-3 rounded ${isIn ? 'bg-green-50 text-green-700' : 'bg-orange-50 text-orange-700'}`}>
            Sau khi {isIn ? 'nhập' : 'xuất'}: <span className="font-bold">
              {isIn ? product.quantity + quantity : Math.max(0, product.quantity - quantity)} {product.unit}
            </span>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Hủy</Button>
          <Button
            onClick={handleSubmit}
            disabled={quantity <= 0 || (type === 'out' && quantity > product.quantity)}
            className={isIn ? 'bg-green-600 hover:bg-green-700' : 'bg-orange-600 hover:bg-orange-700'}
          >
            {isIn ? 'Nhập kho' : 'Xuất kho'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
