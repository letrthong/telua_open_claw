import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Product, StockMovement } from '@/data/inventoryData';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface MovementHistoryProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  product: Product;
  movements: StockMovement[];
}

export function MovementHistory({ open, onOpenChange, product, movements }: MovementHistoryProps) {
  const sorted = [...movements].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Lịch sử nhập/xuất — {product.name}</DialogTitle>
        </DialogHeader>

        <div className="text-sm text-gray-500 mb-2">
          Tồn kho hiện tại: <span className="font-bold">{product.quantity} {product.unit}</span>
        </div>

        {sorted.length === 0 ? (
          <p className="text-center text-gray-400 py-8">Chưa có lịch sử nhập/xuất</p>
        ) : (
          <div className="max-h-80 overflow-y-auto space-y-2">
            {sorted.map(m => {
              const isIn = m.type === 'in';
              return (
                <div key={m.id} className="flex items-center gap-3 p-2 rounded border text-sm">
                  {isIn
                    ? <TrendingUp className="h-4 w-4 text-green-600 shrink-0" />
                    : <TrendingDown className="h-4 w-4 text-orange-600 shrink-0" />
                  }
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <Badge variant={isIn ? 'default' : 'secondary'} className={`text-[10px] ${isIn ? 'bg-green-600' : 'bg-orange-600'}`}>
                        {isIn ? '+' : '-'}{m.quantity}
                      </Badge>
                      <span className="font-medium">{m.reason}</span>
                    </div>
                    {m.note && <div className="text-xs text-gray-400 truncate">{m.note}</div>}
                  </div>
                  <div className="text-xs text-gray-400 shrink-0">
                    {new Date(m.date).toLocaleDateString('vi-VN')}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
