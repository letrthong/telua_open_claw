import { useState, useEffect, useMemo } from 'react';
import { Package, TrendingUp, TrendingDown, AlertTriangle, Search, Plus, ArrowUpDown, FileDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Product, StockMovement, Category,
  loadProducts, saveProducts, loadMovements, saveMovements,
  loadCategories, loadSampleData, UNITS, MOVEMENT_REASONS,
} from '@/data/inventoryData';
import { ProductDialog } from '@/components/inventory/ProductDialog';
import { StockDialog } from '@/components/inventory/StockDialog';
import { MovementHistory } from '@/components/inventory/MovementHistory';
import { useToast } from '@/hooks/use-toast';

const Dashboard = () => {
  const { toast } = useToast();
  const [products, setProducts] = useState<Product[]>([]);
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [categories] = useState<Category[]>(loadCategories);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [sortField, setSortField] = useState<'name' | 'quantity' | 'updatedAt'>('name');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  // Dialogs
  const [productDialogOpen, setProductDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [stockDialogOpen, setStockDialogOpen] = useState(false);
  const [stockProduct, setStockProduct] = useState<Product | null>(null);
  const [stockType, setStockType] = useState<'in' | 'out'>('in');
  const [historyOpen, setHistoryOpen] = useState(false);
  const [historyProduct, setHistoryProduct] = useState<Product | null>(null);

  // Load data
  useEffect(() => {
    let p = loadProducts();
    let m = loadMovements();
    if (p.length === 0) {
      const sample = loadSampleData();
      p = sample.products;
      m = sample.movements;
      saveProducts(p);
      saveMovements(m);
    }
    setProducts(p);
    setMovements(m);
  }, []);

  // Stats
  const stats = useMemo(() => {
    const totalProducts = products.length;
    const totalValue = products.reduce((s, p) => s + p.price * p.quantity, 0);
    const lowStock = products.filter(p => p.quantity <= p.minStock).length;
    const outOfStock = products.filter(p => p.quantity === 0).length;
    return { totalProducts, totalValue, lowStock, outOfStock };
  }, [products]);

  // Filtered & sorted
  const filteredProducts = useMemo(() => {
    let list = products;
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.supplier.toLowerCase().includes(q)
      );
    }
    if (categoryFilter !== 'all') {
      list = list.filter(p => p.category === categoryFilter);
    }
    list = [...list].sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return sortDir === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }
      return sortDir === 'asc' ? Number(aVal) - Number(bVal) : Number(bVal) - Number(aVal);
    });
    return list;
  }, [products, search, categoryFilter, sortField, sortDir]);

  const handleSaveProduct = (product: Product) => {
    const now = new Date().toISOString();
    let updated: Product[];
    if (editingProduct) {
      updated = products.map(p => p.id === product.id ? { ...product, updatedAt: now } : p);
      toast({ title: 'Đã cập nhật', description: `${product.name} đã được cập nhật` });
    } else {
      updated = [...products, { ...product, id: `p${Date.now()}`, createdAt: now, updatedAt: now }];
      toast({ title: 'Đã thêm', description: `${product.name} đã được thêm vào kho` });
    }
    setProducts(updated);
    saveProducts(updated);
    setProductDialogOpen(false);
    setEditingProduct(null);
  };

  const handleDeleteProduct = (id: string) => {
    const p = products.find(x => x.id === id);
    const updated = products.filter(x => x.id !== id);
    setProducts(updated);
    saveProducts(updated);
    toast({ title: 'Đã xóa', description: `${p?.name || id} đã bị xóa` });
  };

  const handleStockChange = (movement: StockMovement) => {
    // Update product quantity
    const updated = products.map(p => {
      if (p.id !== movement.productId) return p;
      const newQty = movement.type === 'in'
        ? p.quantity + movement.quantity
        : Math.max(0, p.quantity - movement.quantity);
      return { ...p, quantity: newQty, updatedAt: new Date().toISOString() };
    });
    setProducts(updated);
    saveProducts(updated);

    // Save movement
    const newMovement = { ...movement, id: `m${Date.now()}`, date: new Date().toISOString() };
    const updatedMovements = [newMovement, ...movements];
    setMovements(updatedMovements);
    saveMovements(updatedMovements);

    const p = products.find(x => x.id === movement.productId);
    toast({
      title: movement.type === 'in' ? 'Nhập kho' : 'Xuất kho',
      description: `${p?.name}: ${movement.type === 'in' ? '+' : '-'}${movement.quantity} ${p?.unit || ''}`,
    });
    setStockDialogOpen(false);
  };

  const handleExportCSV = () => {
    const header = 'SKU,Tên sản phẩm,Danh mục,Số lượng,Đơn vị,Giá bán,Giá vốn,Tồn kho tối thiểu,Vị trí,Nhà cung cấp\n';
    const rows = products.map(p =>
      `"${p.sku}","${p.name}","${p.category}",${p.quantity},"${p.unit}",${p.price},${p.costPrice},${p.minStock},"${p.location}","${p.supplier}"`
    ).join('\n');
    const blob = new Blob(['\ufeff' + header + rows], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tonkho-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({ title: 'Đã xuất CSV', description: `${products.length} sản phẩm` });
  };

  const toggleSort = (field: typeof sortField) => {
    if (sortField === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortField(field); setSortDir('asc'); }
  };

  const getCategoryName = (id: string) => categories.find(c => c.id === id)?.name || id;
  const getCategoryIcon = (id: string) => categories.find(c => c.id === id)?.icon || '📦';

  const formatVND = (n: number) => new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(n);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Package className="h-8 w-8 text-blue-600" />
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">Quản Lý Kho Hàng</h1>
              <p className="text-xs text-gray-500">Inventory Management System</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleExportCSV}>
              <FileDown className="h-4 w-4 mr-1" /> Xuất CSV
            </Button>
            <Button size="sm" onClick={() => { setEditingProduct(null); setProductDialogOpen(true); }}>
              <Plus className="h-4 w-4 mr-1" /> Thêm sản phẩm
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-gray-500 font-normal">Tổng sản phẩm</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalProducts}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-gray-500 font-normal">Giá trị tồn kho</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{formatVND(stats.totalValue)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-gray-500 font-normal flex items-center gap-1">
                <AlertTriangle className="h-3 w-3 text-yellow-500" /> Sắp hết hàng
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">{stats.lowStock}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-gray-500 font-normal">Hết hàng</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{stats.outOfStock}</div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Tìm kiếm theo tên, SKU, nhà cung cấp..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Danh mục" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tất cả danh mục</SelectItem>
              {categories.map(c => (
                <SelectItem key={c.id} value={c.id}>{c.icon} {c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Products Table */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-gray-50 dark:bg-gray-900">
                    <th className="text-left p-3 font-medium text-gray-500 cursor-pointer" onClick={() => toggleSort('name')}>
                      <span className="flex items-center gap-1">Sản phẩm <ArrowUpDown className="h-3 w-3" /></span>
                    </th>
                    <th className="text-left p-3 font-medium text-gray-500">SKU</th>
                    <th className="text-left p-3 font-medium text-gray-500">Danh mục</th>
                    <th className="text-right p-3 font-medium text-gray-500 cursor-pointer" onClick={() => toggleSort('quantity')}>
                      <span className="flex items-center gap-1 justify-end">Tồn kho <ArrowUpDown className="h-3 w-3" /></span>
                    </th>
                    <th className="text-right p-3 font-medium text-gray-500">Giá bán</th>
                    <th className="text-left p-3 font-medium text-gray-500">Vị trí</th>
                    <th className="text-center p-3 font-medium text-gray-500">Thao tác</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map(product => {
                    const isLow = product.quantity <= product.minStock && product.quantity > 0;
                    const isOut = product.quantity === 0;
                    return (
                      <tr key={product.id} className="border-b hover:bg-gray-50 dark:hover:bg-gray-900/50">
                        <td className="p-3">
                          <div className="font-medium">{product.name}</div>
                          <div className="text-xs text-gray-400">{product.description}</div>
                        </td>
                        <td className="p-3 font-mono text-xs">{product.sku}</td>
                        <td className="p-3">
                          <Badge variant="outline" className="text-xs">
                            {getCategoryIcon(product.category)} {getCategoryName(product.category)}
                          </Badge>
                        </td>
                        <td className="p-3 text-right">
                          <span className={`font-bold ${isOut ? 'text-red-600' : isLow ? 'text-yellow-600' : 'text-green-600'}`}>
                            {product.quantity}
                          </span>
                          <span className="text-gray-400 ml-1">{product.unit}</span>
                          {isLow && <AlertTriangle className="h-3 w-3 inline ml-1 text-yellow-500" />}
                          {isOut && <Badge variant="destructive" className="ml-1 text-[10px] px-1">Hết</Badge>}
                        </td>
                        <td className="p-3 text-right">{formatVND(product.price)}</td>
                        <td className="p-3 font-mono text-xs">{product.location}</td>
                        <td className="p-3">
                          <div className="flex items-center justify-center gap-1">
                            <Button variant="ghost" size="sm" className="h-7 px-2 text-green-600"
                              onClick={() => { setStockProduct(product); setStockType('in'); setStockDialogOpen(true); }}>
                              <TrendingUp className="h-3 w-3 mr-1" />Nhập
                            </Button>
                            <Button variant="ghost" size="sm" className="h-7 px-2 text-orange-600"
                              onClick={() => { setStockProduct(product); setStockType('out'); setStockDialogOpen(true); }}>
                              <TrendingDown className="h-3 w-3 mr-1" />Xuất
                            </Button>
                            <Button variant="ghost" size="sm" className="h-7 px-2"
                              onClick={() => { setHistoryProduct(product); setHistoryOpen(true); }}>
                              📋
                            </Button>
                            <Button variant="ghost" size="sm" className="h-7 px-2"
                              onClick={() => { setEditingProduct(product); setProductDialogOpen(true); }}>
                              ✏️
                            </Button>
                            <Button variant="ghost" size="sm" className="h-7 px-2 text-red-500"
                              onClick={() => handleDeleteProduct(product.id)}>
                              🗑️
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {filteredProducts.length === 0 && (
                    <tr><td colSpan={7} className="p-8 text-center text-gray-400">
                      {search || categoryFilter !== 'all' ? 'Không tìm thấy sản phẩm' : 'Chưa có sản phẩm nào. Nhấn "Thêm sản phẩm" để bắt đầu.'}
                    </td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Dialogs */}
      <ProductDialog
        open={productDialogOpen}
        onOpenChange={setProductDialogOpen}
        product={editingProduct}
        categories={categories}
        onSave={handleSaveProduct}
      />
      {stockProduct && (
        <StockDialog
          open={stockDialogOpen}
          onOpenChange={setStockDialogOpen}
          product={stockProduct}
          type={stockType}
          onSave={handleStockChange}
        />
      )}
      {historyProduct && (
        <MovementHistory
          open={historyOpen}
          onOpenChange={setHistoryOpen}
          product={historyProduct}
          movements={movements.filter(m => m.productId === historyProduct.id)}
        />
      )}
    </div>
  );
};

export default Dashboard;
