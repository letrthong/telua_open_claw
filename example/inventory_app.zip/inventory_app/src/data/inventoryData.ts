// ===== Inventory Management Data Models =====

export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  description: string;
  unit: string;         // pcs, kg, box, etc.
  price: number;
  costPrice: number;
  quantity: number;
  minStock: number;     // minimum stock level for alert
  location: string;     // warehouse location / shelf
  supplier: string;
  image?: string;
  createdAt: string;
  updatedAt: string;
}

export interface StockMovement {
  id: string;
  productId: string;
  type: 'in' | 'out';
  quantity: number;
  reason: string;       // purchase, sale, return, adjustment, damaged
  note: string;
  date: string;
  createdBy: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'electronics', name: 'Điện tử', icon: '💻', color: '#3B82F6' },
  { id: 'food', name: 'Thực phẩm', icon: '🍜', color: '#22C55E' },
  { id: 'clothing', name: 'Quần áo', icon: '👕', color: '#A855F7' },
  { id: 'tools', name: 'Dụng cụ', icon: '🔧', color: '#F59E0B' },
  { id: 'materials', name: 'Nguyên liệu', icon: '📦', color: '#EF4444' },
  { id: 'other', name: 'Khác', icon: '📋', color: '#6B7280' },
];

export const UNITS = ['pcs', 'kg', 'g', 'lít', 'hộp', 'thùng', 'bao', 'cuộn', 'cái', 'bộ', 'đôi', 'mét'];

export const MOVEMENT_REASONS = {
  in: ['Nhập mua', 'Trả hàng', 'Điều chỉnh tăng', 'Sản xuất', 'Chuyển kho đến'],
  out: ['Bán hàng', 'Hàng hỏng', 'Điều chỉnh giảm', 'Xuất sử dụng', 'Chuyển kho đi'],
};

// ===== LocalStorage persistence =====
const PRODUCTS_KEY = 'inventory-products';
const MOVEMENTS_KEY = 'inventory-movements';
const CATEGORIES_KEY = 'inventory-categories';

export function loadProducts(): Product[] {
  try {
    const data = localStorage.getItem(PRODUCTS_KEY);
    return data ? JSON.parse(data) : [];
  } catch { return []; }
}

export function saveProducts(products: Product[]) {
  localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
}

export function loadMovements(): StockMovement[] {
  try {
    const data = localStorage.getItem(MOVEMENTS_KEY);
    return data ? JSON.parse(data) : [];
  } catch { return []; }
}

export function saveMovements(movements: StockMovement[]) {
  localStorage.setItem(MOVEMENTS_KEY, JSON.stringify(movements));
}

export function loadCategories(): Category[] {
  try {
    const data = localStorage.getItem(CATEGORIES_KEY);
    return data ? JSON.parse(data) : DEFAULT_CATEGORIES;
  } catch { return DEFAULT_CATEGORIES; }
}

export function saveCategories(categories: Category[]) {
  localStorage.setItem(CATEGORIES_KEY, JSON.stringify(categories));
}

// ===== Sample data for first load =====
export function loadSampleData(): { products: Product[]; movements: StockMovement[] } {
  const now = new Date().toISOString();
  const products: Product[] = [
    { id: 'p1', name: 'Laptop Dell Inspiron 15', sku: 'DELL-INS15', category: 'electronics', description: 'Laptop Dell 15 inch, Core i5, 8GB RAM', unit: 'cái', price: 15000000, costPrice: 12000000, quantity: 25, minStock: 5, location: 'A1-01', supplier: 'Dell Vietnam', createdAt: now, updatedAt: now },
    { id: 'p2', name: 'Chuột không dây Logitech', sku: 'LOG-M185', category: 'electronics', description: 'Chuột không dây Logitech M185', unit: 'cái', price: 250000, costPrice: 180000, quantity: 150, minStock: 20, location: 'A1-03', supplier: 'Logitech VN', createdAt: now, updatedAt: now },
    { id: 'p3', name: 'Gạo ST25', sku: 'FOOD-ST25', category: 'food', description: 'Gạo ST25 Sóc Trăng 5kg', unit: 'bao', price: 120000, costPrice: 95000, quantity: 80, minStock: 10, location: 'B2-01', supplier: 'Nông sản Sóc Trăng', createdAt: now, updatedAt: now },
    { id: 'p4', name: 'Áo thun nam', sku: 'CLT-TSHIRT', category: 'clothing', description: 'Áo thun nam cotton, size M-XL', unit: 'cái', price: 180000, costPrice: 85000, quantity: 200, minStock: 30, location: 'C1-02', supplier: 'May mặc Bình Dương', createdAt: now, updatedAt: now },
    { id: 'p5', name: 'Bộ cờ lê đa năng', sku: 'TOOL-WRENCH', category: 'tools', description: 'Bộ cờ lê 12 chi tiết', unit: 'bộ', price: 350000, costPrice: 220000, quantity: 45, minStock: 10, location: 'D1-01', supplier: 'Dụng cụ Đại Phát', createdAt: now, updatedAt: now },
    { id: 'p6', name: 'Xi măng PCB40', sku: 'MAT-CEMENT', category: 'materials', description: 'Xi măng PCB40 bao 50kg', unit: 'bao', price: 95000, costPrice: 72000, quantity: 3, minStock: 10, location: 'E1-01', supplier: 'Hà Tiên 1', createdAt: now, updatedAt: now },
  ];
  const movements: StockMovement[] = [
    { id: 'm1', productId: 'p1', type: 'in', quantity: 30, reason: 'Nhập mua', note: 'Đơn hàng #PO-001', date: now, createdBy: 'Admin' },
    { id: 'm2', productId: 'p1', type: 'out', quantity: 5, reason: 'Bán hàng', note: 'Đơn hàng #SO-001', date: now, createdBy: 'Admin' },
    { id: 'm3', productId: 'p2', type: 'in', quantity: 200, reason: 'Nhập mua', note: 'Đơn hàng #PO-002', date: now, createdBy: 'Admin' },
    { id: 'm4', productId: 'p2', type: 'out', quantity: 50, reason: 'Bán hàng', note: '', date: now, createdBy: 'Admin' },
  ];
  return { products, movements };
}
