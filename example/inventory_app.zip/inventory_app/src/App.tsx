import { Toaster } from "@/components/ui/toaster";
import Dashboard from "@/pages/Dashboard";

function App() {
  return (
    <>
      <Dashboard />
      <Toaster />
    </>
  );
}

export default App;
