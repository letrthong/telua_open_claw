# service_code.py
# Python service code for data storage using Flask (skeleton)

from flask import Flask, request, jsonify, send_from_directory
import os

app = Flask(__name__)

# Example in-memory data store (replace with persistent storage as needed)
data_store = {}

@app.route('/data', methods=['GET'])
def get_data():
    return jsonify(data_store)

@app.route('/data', methods=['POST'])
def set_data():
    content = request.json
    if not content or 'key' not in content or 'value' not in content:
        return jsonify({'error': 'Invalid payload'}), 400
    data_store[content['key']] = content['value']
    return jsonify({'status': 'success'})

@app.route('/')
def serve_index():
    # Trả về file index.html từ /app/dist (đường dẫn tuyệt đối trong container)
    return send_from_directory('/app/dist', 'index.html')

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
