1/ How to create to start Docker
	Start docker on Ubuntu
		cd docker
		./build_docker.sh
	Working on Docker container
		cd /app

		npm install
		npm run build
		
		outputs  at dist/index.html
	
2/ Nodejs 
	https://nodejs.org/en
	Because we can not download nodejs and install via cli so node-v24.14.0-linux-x64.tar was downloaded to install
	
3/ How to start docker again
    Start docker on Ubuntu
	   cd docker
	   ./restart_docker.sh
	   
4/ dist for single page on Ubuntu 
   we configured to sycn /app/dist on docker container with ./dist on Ubuntu (Check at docker-compose.yml)



mkdir flask_wheels
pip download \
    --only-binary=:all: \
    --platform manylinux2014_x86_64 \
    --python-version 311 \
    --implementation cp \
    --abi cp311 \
    -d ./flask_wheels \
    flask