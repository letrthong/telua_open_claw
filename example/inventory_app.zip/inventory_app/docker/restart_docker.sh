#!/bin/bash
set -e

cd  ../

# Updated to match the new name in docker-compose.yml
CONTAINER_NAME="inventor_container"

echo "🛠️  [Step 1/2] Rebuilding and starting container..."
docker-compose down
#docker-compose up --build -d

echo "⏳ Waiting for container to stabilize..."
sleep 2

echo "🚀 [Step 2/2]  Executing: /app/single_page.sh ---"

# Note: We use -w /app to ensure the script runs in its home directory
 
docker exec -w /app $CONTAINER_NAME /bin/sh ./single_page.sh

# Try bash first, fallback to sh
# docker exec -it $CONTAINER_NAME /bin/bash 2>/dev/null || \
# docker exec -it $CONTAINER_NAME /bin/sh
