# 1. Clean out the old folder
rm -rf ./flask_wheels/*

# 2. Download Flask AND all its requirements
pip download \
    --only-binary=:all: \
    --platform manylinux2014_x86_64 \
    --python-version 310 \
    -d ./flask_wheels \
    flask


# 3. Check Python version (should be 3.11 for markupsafe cp311 wheel)
python3 --version